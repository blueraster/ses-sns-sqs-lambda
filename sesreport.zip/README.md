## Synopsis

A modified version of the lambda dashboard generator for ses found here https://github.com/awslabs/aws-support-tools/tree/master/SES/SESReports .

Includes the field 'From' in the dashboard so it can be determined which email list a specific bounced email is coming from.